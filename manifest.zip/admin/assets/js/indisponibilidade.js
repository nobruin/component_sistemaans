jQuery.getScript( "https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js", function( data, textStatus, jqxhr ) {
    jQuery('.calendar').mask('00/00/0000 00:00:00');
  });