<?php 

defined('_JEXEC') or die('Restricted access');

class SistemasAnsControllerIndisponibilidade extends JControllerForm
{

}
