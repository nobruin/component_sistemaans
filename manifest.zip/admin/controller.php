<?php

class SistemasAnsController extends JControllerLegacy
{
    protected $default_view = 'servicos';
}



