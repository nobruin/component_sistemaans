DROP TABLE IF EXISTS  `#__servicos`;
DROP TABLE IF EXISTS  `#__indisponibilidade`;
DROP TABLE IF EXISTS  `#__servico_relacionados`;

