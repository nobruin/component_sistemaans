<?php

defined('_JEXEC') or die('Restricted access');

class SistemasAnsController extends JControllerLegacy
{
    protected $default_view = 'servicos';
}